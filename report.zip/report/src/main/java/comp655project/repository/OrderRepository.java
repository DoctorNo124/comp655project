package comp655project.repository;

import comp655project.model.Order;
import io.quarkus.hibernate.orm.panache.PanacheRepository;
import io.quarkus.hibernate.reactive.panache.common.runtime.PanacheHibernateRecorder;

public class OrderRepository implements PanacheRepository<Order> {
}