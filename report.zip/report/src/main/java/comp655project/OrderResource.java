package comp655project;

import java.util.List;

import comp655project.model.Order;
import comp655project.repository.OrderRepository;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("/order")
public class OrderResource {


	
	@POST
    @Consumes(MediaType.APPLICATION_JSON)
    public String create_order(Order order) {
		OrderRepository orderRepository=new OrderRepository();
		orderRepository.persist(order);
        return "Order Saved Successfully";
    }
	@GET
    @Produces(MediaType.APPLICATION_JSON)
    public List<Order> get_order() {
		OrderRepository orderRepository=new OrderRepository();
        return orderRepository.findAll().list();
    }
	@GET
	@Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Order get_order_id(long id) {
		OrderRepository orderRepository=new OrderRepository();
        return orderRepository.findById(id);
    }
	@DELETE
	@Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public boolean delete_order_id(long id) {
		OrderRepository orderRepository=new OrderRepository();
        return orderRepository.deleteById(id);
    }
}

